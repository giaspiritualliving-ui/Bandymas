# 🎬 WOWsilizing Bot

**Telegram бот для обработки видео с AI функциями**

[![Railway Deploy](https://img.shields.io/badge/Deploy%20on-Railway-blueviolet?style=for-the-badge&logo=railway)](https://railway.app/)
[![Python](https://img.shields.io/badge/Python-3.11+-blue?style=for-the-badge&logo=python)](https://www.python.org/)
[![Telegram](https://img.shields.io/badge/Telegram-Bot-blue?style=for-the-badge&logo=telegram)](https://core.telegram.org/bots)

---

## 📖 О проекте

**WOWsilizing Bot** — это мощный Telegram бот для обработки видео с интеграцией современных AI сервисов. Бот предоставляет как бесплатные базовые функции, так и премиум возможности с использованием искусственного интеллекта.

### ✨ Основные возможности

#### 🆓 Бесплатные функции
- 📹 Обработка видео из Telegram
- 🔗 Скачивание видео с YouTube и других платформ
- 📊 Статистика использования
- 💾 Сохранение истории обработки

#### 👑 Премиум функции (требуют API ключи)
- 🎤 **Транскрипция аудио** — преобразование речи в текст (OpenAI Whisper)
- 🤖 **AI чат** — умный помощник на базе GPT-4 и Gemini
- 🔊 **Генерация голоса** — озвучка текста (OpenAI TTS, ElevenLabs)
- 🎨 **Обработка изображений** — AI анализ и генерация

---

## 🚀 Быстрый старт

### Вариант 1: Развертывание на Railway (рекомендуется)

**Самый простой способ для начинающих!**

1. 📖 Прочитайте [**COMPLETE_GUIDE.md**](COMPLETE_GUIDE.md) — подробное руководство на русском языке
2. ⚡ Или используйте [**QUICK_REFERENCE.md**](QUICK_REFERENCE.md) — краткая справка

**Что вам понадобится:**
- Аккаунт на [GitHub](https://github.com/signup)
- Аккаунт на [Railway](https://railway.app/)
- Токен бота от [@BotFather](https://t.me/BotFather)
- 30-40 минут времени

**Преимущества Railway:**
- ✅ Бесплатно ($5 кредитов каждый месяц)
- ✅ Автоматическое развертывание из GitHub
- ✅ Работает 24/7
- ✅ Простая настройка без командной строки

### Вариант 2: Локальный запуск

Для разработчиков и тестирования:

```bash
# 1. Клонируйте репозиторий
git clone https://github.com/ваш-username/wowsilizing-bot.git
cd wowsilizing-bot

# 2. Создайте виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows

# 3. Установите зависимости
pip install -r requirements.txt

# 4. Создайте файл .env
cp .env.example .env
# Отредактируйте .env и добавьте ваши ключи

# 5. Запустите бота
python bot.py
```

---

## ⚙️ Настройка

### Обязательные переменные окружения

Создайте файл `.env` или добавьте переменные в Railway:

```env
# Токен бота от @BotFather
BOT_TOKEN=your_bot_token_here

# Username премиум пользователя (без @)
PREMIUM_USERNAME=WowFUX
```

### Опциональные переменные (для AI функций)

```env
# OpenAI API Key (для Whisper, GPT-4, TTS)
OPENAI_API_KEY=sk-...

# Google Generative AI API Key (для Gemini)
GOOGLE_API_KEY=...

# ElevenLabs API Key (для голосовой озвучки)
ELEVENLABS_API_KEY=...

# Уровень логирования
LOG_LEVEL=INFO
```

### Где получить API ключи?

| Сервис | Ссылка | Назначение |
|--------|--------|------------|
| **OpenAI** | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) | Whisper, GPT-4, TTS |
| **Google AI** | [makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey) | Gemini |
| **ElevenLabs** | [elevenlabs.io](https://elevenlabs.io/) | Голосовая озвучка |

---

## 📋 Требования

### Системные требования
- Python 3.11 или выше
- 512 MB RAM (минимум)
- 1 GB свободного места на диске

### Python зависимости

Основные библиотеки (см. `requirements.txt`):
- `aiogram==3.4.1` — Telegram Bot Framework
- `openai==1.12.0` — OpenAI API
- `google-generativeai==0.3.2` — Google Gemini
- `elevenlabs==0.2.27` — ElevenLabs API
- `aiosqlite==0.19.0` — База данных
- `yt-dlp==2023.12.30` — Скачивание видео

---

## 🎮 Использование

### Команды бота

```
/start    - Запуск бота и главное меню
/help     - Список всех команд и инструкции
/stats    - Статистика использования
```

### Основные функции

1. **Обработка видео**:
   - Отправьте видео файл боту
   - Или отправьте ссылку на YouTube видео
   - Бот обработает и вернет результат

2. **Транскрипция аудио** (премиум):
   - Отправьте голосовое сообщение
   - Или аудио файл
   - Получите текстовую расшифровку

3. **AI чат** (премиум):
   - Задайте вопрос боту
   - Получите умный ответ от GPT-4 или Gemini

4. **Генерация голоса** (премиум):
   - Отправьте текст
   - Получите аудио с озвучкой

---

## 📁 Структура проекта

```
wowsilizing-bot/
├── bot.py                  # Главный файл бота
├── ai_processor.py         # Обработка AI запросов
├── database.py             # Работа с базой данных
├── utils.py                # Вспомогательные функции
├── video_processor.py      # Обработка видео
├── config.py               # Конфигурация
├── requirements.txt        # Python зависимости
├── Dockerfile              # Docker образ
├── railway.json            # Настройки Railway
├── .env.example            # Пример переменных окружения
├── .gitignore              # Игнорируемые файлы
├── .dockerignore           # Игнорируемые при сборке
├── README.md               # Этот файл
├── COMPLETE_GUIDE.md       # Полное руководство по развертыванию
└── QUICK_REFERENCE.md      # Быстрая справка
```

---

## 🔧 Разработка

### Локальная разработка

1. Форкните репозиторий
2. Клонируйте ваш форк
3. Создайте ветку для изменений:
   ```bash
   git checkout -b feature/my-new-feature
   ```
4. Внесите изменения
5. Закоммитьте:
   ```bash
   git commit -m "Добавлена новая функция"
   ```
6. Запушьте в ваш форк:
   ```bash
   git push origin feature/my-new-feature
   ```
7. Создайте Pull Request

### Тестирование

```bash
# Запуск тестов (если есть)
python -m pytest

# Проверка кода
python -m pylint bot.py
```

---

## 🐳 Docker

### Сборка образа

```bash
docker build -t wowsilizing-bot .
```

### Запуск контейнера

```bash
docker run -d \
  --name wowsilizing-bot \
  --env-file .env \
  wowsilizing-bot
```

### Docker Compose

```yaml
version: '3.8'
services:
  bot:
    build: .
    env_file: .env
    restart: unless-stopped
    volumes:
      - ./data:/app/data
```

---

## 📊 Мониторинг

### Логи

Бот записывает логи в консоль. Уровень логирования настраивается через `LOG_LEVEL`:

- `DEBUG` — подробная информация для отладки
- `INFO` — основные события (по умолчанию)
- `WARNING` — предупреждения
- `ERROR` — только ошибки

### Метрики на Railway

В панели Railway доступны:
- 📈 Использование CPU и памяти
- 💰 Расход кредитов
- 📋 Логи в реальном времени
- ✅ Статус развертывания

---

## 🔒 Безопасность

### Важные правила:

- ⚠️ **НИКОГДА** не коммитьте файл `.env` с реальными ключами
- ⚠️ Используйте `.gitignore` для исключения секретных файлов
- ⚠️ Не публикуйте токен бота в открытом доступе
- ⚠️ Регулярно обновляйте зависимости
- ⚠️ Используйте переменные окружения для всех секретов

### Что делать, если токен утек:

1. Откройте [@BotFather](https://t.me/BotFather)
2. Отправьте `/mybots`
3. Выберите вашего бота
4. Нажмите **API Token** → **Revoke current token**
5. Получите новый токен
6. Обновите `BOT_TOKEN` в Railway

---

## 🐛 Устранение неполадок

### Частые проблемы

**Бот не запускается:**
- Проверьте правильность `BOT_TOKEN`
- Убедитесь, что все обязательные переменные установлены
- Проверьте логи на наличие ошибок

**AI функции не работают:**
- Проверьте наличие API ключей
- Убедитесь, что на балансе AI сервисов есть средства
- Проверьте, что ключи активны и не истекли

**Закончились кредиты на Railway:**
- Проверьте использование в разделе **Usage**
- Оптимизируйте запросы к AI сервисам
- Добавьте карту для продолжения (минимум $5)

Подробнее см. раздел **Устранение неполадок** в [COMPLETE_GUIDE.md](COMPLETE_GUIDE.md)

---

## 📚 Документация

- 📖 [**COMPLETE_GUIDE.md**](COMPLETE_GUIDE.md) — Полное руководство по развертыванию (для начинающих)
- ⚡ [**QUICK_REFERENCE.md**](QUICK_REFERENCE.md) — Быстрая справка и чек-листы
- 🔗 [Telegram Bot API](https://core.telegram.org/bots/api) — Официальная документация Telegram
- 🚂 [Railway Docs](https://docs.railway.app/) — Документация Railway

---

## 💰 Стоимость

### Railway
- **Бесплатно**: $5 кредитов каждый месяц
- **Платно**: $5+ по мере необходимости
- Для Telegram бота обычно достаточно бесплатных кредитов

### AI Сервисы (опционально)

| Сервис | Бесплатный лимит | Стоимость |
|--------|------------------|-----------|
| **OpenAI** | $5 при регистрации | От $0.002 за 1K токенов |
| **Google AI** | 60 запросов/минуту | Бесплатно (с ограничениями) |
| **ElevenLabs** | 10,000 символов/месяц | От $5/месяц |

---

## 🤝 Вклад в проект

Мы приветствуем вклад в развитие проекта!

### Как помочь:

1. 🐛 Сообщайте о багах через [Issues](https://github.com/ваш-username/wowsilizing-bot/issues)
2. 💡 Предлагайте новые функции
3. 📝 Улучшайте документацию
4. 🔧 Отправляйте Pull Requests с исправлениями

### Правила:

- Следуйте стилю кода проекта
- Добавляйте комментарии к сложным участкам
- Тестируйте изменения перед отправкой
- Пишите понятные commit messages

---

## 📄 Лицензия

Этот проект распространяется под лицензией MIT. См. файл `LICENSE` для подробностей.

```
MIT License

Copyright (c) 2024 WOWsilizing Bot

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 👨‍💻 Автор

**WOWsilizing Bot** создан для упрощения работы с видео в Telegram.

### Контакты:

- 📧 Email: [ваш-email@example.com](mailto:ваш-email@example.com)
- 💬 Telegram: [@ваш_username](https://t.me/ваш_username)
- 🐙 GitHub: [github.com/ваш-username](https://github.com/ваш-username)

---

## 🙏 Благодарности

Спасибо всем, кто использует и развивает этот проект!

Особая благодарность:
- [aiogram](https://github.com/aiogram/aiogram) — отличный фреймворк для Telegram ботов
- [OpenAI](https://openai.com/) — за мощные AI модели
- [Railway](https://railway.app/) — за простой хостинг
- [yt-dlp](https://github.com/yt-dlp/yt-dlp) — за скачивание видео

---

## 📈 Статус проекта

![GitHub last commit](https://img.shields.io/github/last-commit/ваш-username/wowsilizing-bot?style=flat-square)
![GitHub issues](https://img.shields.io/github/issues/ваш-username/wowsilizing-bot?style=flat-square)
![GitHub stars](https://img.shields.io/github/stars/ваш-username/wowsilizing-bot?style=flat-square)

**Версия**: 1.0.0  
**Статус**: Активная разработка  
**Последнее обновление**: Ноябрь 2024

---

## 🎯 Дорожная карта

### Планируемые функции:

- [ ] Поддержка больше видео платформ
- [ ] Улучшенная обработка видео
- [ ] Интеграция с большим количеством AI моделей
- [ ] Веб-интерфейс для управления
- [ ] Поддержка нескольких языков
- [ ] Расширенная аналитика
- [ ] API для интеграции с другими сервисами

---

## ❓ FAQ

### Нужно ли платить за использование бота?

Нет, базовые функции бесплатны. AI функции требуют API ключи, которые могут быть платными.

### Можно ли использовать бота без AI функций?

Да! Бот работает с базовыми функциями, используя только `BOT_TOKEN` и `PREMIUM_USERNAME`.

### Сколько стоит хостинг на Railway?

Railway дает $5 бесплатных кредитов каждый месяц. Для небольшого бота этого достаточно.

### Как обновить бота?

Внесите изменения в файлы на GitHub. Railway автоматически обнаружит изменения и перезапустит бота.

### Безопасно ли хранить код на GitHub?

Да, если вы не публикуете секретные ключи. Используйте `.gitignore` и переменные окружения.

### Можно ли запустить бота на своем сервере?

Да! Используйте Docker или запустите напрямую через Python. См. раздел [Локальный запуск](#вариант-2-локальный-запуск).

---

<div align="center">

**Сделано с ❤️ для сообщества Telegram**

⭐ Поставьте звезду, если проект вам понравился!

[🚀 Развернуть на Railway](https://railway.app/) | [📖 Документация](COMPLETE_GUIDE.md) | [⚡ Быстрая справка](QUICK_REFERENCE.md)

</div>
