"""Конфигурация бота WOWsilizing."""
import os
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Основные настройки бота
BOT_TOKEN = os.getenv("BOT_TOKEN", "8314895069:AAG1P9oozBOHv1pMaIPy-uzGQhayu6Fz9c8")
BOT_USERNAME = "@WOWsilizing"
PREMIUM_USERNAME = os.getenv("PREMIUM_USERNAME", "@WowFUX").lower().replace("@", "")

# API ключи для AI сервисов (только для премиум)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")

# Приоритетные языки для обработки
PRIORITY_LANGUAGES = ["lt", "ru", "en", "uk"]

# Лимиты и ограничения
MAX_FILE_SIZE_MB = 50  # Максимальный размер файла в MB
MAX_VIDEO_DURATION = 3600  # Максимальная длительность видео в секундах (1 час)
MAX_QUEUE_SIZE = 10  # Максимальное количество задач в очереди на пользователя
MAX_BATCH_SEGMENTS = 100  # Максимальное количество сегментов в пакетной обработке

# Пути к директориям
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMP_DIR = os.path.join(BASE_DIR, "temp")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
CACHE_DIR = os.path.join(DATA_DIR, "cache")

# База данных
DATABASE_PATH = os.path.join(DATA_DIR, "bot.db")

# Настройки обработки видео
DEFAULT_VIDEO_CODEC = "libx264"
DEFAULT_AUDIO_CODEC = "aac"
DEFAULT_CRF = 23  # Quality (lower = better, 18-28 is good range)
DEFAULT_PRESET = "medium"  # Скорость кодирования (ultrafast, superfast, veryfast, faster, fast, medium, slow, slower, veryslow)

# Настройки аудио
DEFAULT_AUDIO_BITRATE = "192k"
DEFAULT_SAMPLE_RATE = 44100

# Настройки нормализации аудио
LOUDNESS_TARGET = -16  # LUFS
LOUDNESS_RANGE = 11  # LU
LOUDNESS_TRUE_PEAK = -1.5  # dBTP

# Голоса для TTS
OPENAI_TTS_VOICES = ["alloy", "echo", "fable", "onyx", "nova", "shimmer"]
OPENAI_TTS_MODELS = ["tts-1", "tts-1-hd"]

# Настройки кеширования
CACHE_EXPIRY_DAYS = 7  # Срок хранения кеша в днях
CACHE_MAX_SIZE_GB = 5  # Максимальный размер кеша в GB

# Настройки логирования
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = os.path.join(LOGS_DIR, "bot.log")

# Создание необходимых директорий
for directory in [TEMP_DIR, DATA_DIR, LOGS_DIR, CACHE_DIR]:
    os.makedirs(directory, exist_ok=True)

# Тексты сообщений (все на русском)
MESSAGES = {
    "start": """👋 Добро пожаловать в WOWsilizing Bot!

🎬 Я помогу вам обработать видео профессионально.

📱 БЕСПЛАТНЫЕ функции (для всех):
• Нарезка видео по таймкодам
• ⭐ ПАКЕТНАЯ нарезка (до 100 сегментов за раз!)
• Извлечение аудио (MP3/WAV)
• Шумоподавление и нормализация звука
• Сжатие и конвертация форматов
• Конвертация в вертикальный формат 9:16
• Авто-сегментация по длительности
• Удаление пауз/тишины
• Склейка нескольких видео

👑 ПРЕМИУМ функции (только для @WowFUX):
• Автоматические субтитры (Whisper AI)
• Перевод субтитров
• Озвучка текста (3 сервиса: OpenAI, Google, 11Labs)
• Автоматические хайлайты для shorts
• Резюме и главы видео
• Умные команды на естественном языке
• Статистика использования API

Выберите действие из меню или отправьте видео!""",
    
    "premium_only": "❌ Эта функция доступна только для премиум-пользователей (@WowFUX)",
    "processing": "⏳ Обрабатываю... {progress}%",
    "completed": "✅ Готово! Файл обработан успешно.",
    "error": "❌ Ошибка: {error}",
    "file_too_large": "❌ Файл слишком большой. Максимальный размер: {max_size} MB",
    "invalid_timecode": "❌ Неверный формат таймкода. Используйте формат: HH:MM:SS-HH:MM:SS или MM:SS-MM:SS",
    "queue_full": "❌ Очередь заполнена. Подождите завершения текущих задач.",
    "segments_found": "✅ Найдено {count} сегментов. Начать обработку?",
    "processing_segment": "⏳ Обрабатываю сегмент {current}/{total}...",
    "no_video": "❌ Сначала отправьте видео файл или YouTube ссылку.",
    "downloading": "⬇️ Скачиваю видео...",
    "cache_hit": "⚡ Найден готовый результат в кеше!",
}
